﻿using System;
namespace Categorias
{

    class Program
    {
        static void Main(String[] args)
        {
            Console.WriteLine("Bem vindo ao sistema! \n");
            Menu.MenuNavegar();


        }
    }
}