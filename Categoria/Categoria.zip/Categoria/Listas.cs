﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Categorias
//{
//    public class Listas
//    {


//        private string Nome;
//        public int ProximaPosicao;
//        List<Categoria> lista = new List<Categoria>();


//        public string Adicionar()
//        {
//            Categoria categoria = new Categoria();

//            categoria.Cadastrar();
//            lista.Add(categoria);
//            return "cadastrado";
//        }

//        public void Pesquisar()
//        {

//            foreach (Categoria item in lista)
//            {
//                Console.WriteLine(item);
//            }

//        }
//    }
//}